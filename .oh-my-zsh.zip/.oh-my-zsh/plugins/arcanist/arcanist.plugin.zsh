#
# Aliases
# (sorted alphabetically)
#

alias ara='arc amend'
alias arb='arc branch'
alias arco='arc cover'
alias arci='arc commit'

alias ard='arc diff'
alias ardnu='arc diff --nounit'
alias ardnupc='arc diff --nounit --plan-changes'
alias ardpc='arc diff --plan-changes'

alias are='arc export'
alias arh='arc help'
alias arl='arc land'
alias arli='arc lint'
alias arls='arc list'
alias arpa='arc patch'
